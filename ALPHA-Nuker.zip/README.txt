Hello I'm Protocol and I'm the owner of ALPHA-Nuker
Following are the steps to setup ALPHA-Nuker:

1)Install the latest version of Python from the internet
2)While installing Python make sure to select "Add Python to PATH" option
3)After python, run install.bat as an admin to install all the required modules
4)It will launch automatically after installation
5)Whenever you want to open the nuker run start.bat as an admin
6) Enjoy!

NOTE :- THIS TOOL IS STRICTLY FOR EDUCATIONAL PURPOSES ONLY, USE IT ONLY TO PRANK OR FOR HAVING FUN WITH FRIENDS. DO NOT NUKE SERVERS WITHOUT PERMISSION IT IS AGAINST THE DISCORD TOS, I AM NOT RESPONSIBLE FOR ANYTHING THAT HAPPENS IF YOU DONT FOLLOW THE RULES.

Copyright Belongs To :- Protocol
